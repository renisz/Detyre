let vleraBalance = 0; 

const depozito = document.getElementById("depozito");
const terhiq = document.getElementById("terhiq");
const balanca = document.getElementById("balanca");

depozito.addEventListener("click", function() {
    var vleraDepozitim = parseFloat(prompt("Sa do te depozitosh:"));
    if (!isNaN(vleraDepozitim) && vleraDepozitim > 0) {
        vleraBalance += vleraDepozitim; 
        alert(`Ti depozitove ${vleraDepozitim} lek`);
    } else {
        alert("Ju lutem, jepni nje vlere te vlefshme per depozitim.");
    }
    alert(`Balanca jote eshte ${vleraBalance} lek`);
});
1
terhiq.addEventListener("click", function() {
    var vleraTerheqje = parseFloat(prompt("Sa leke do te terheqesh:"));
    if (!isNaN(vleraTerheqje) && vleraTerheqje > 0 && vleraTerheqje <= vleraBalance) {
        vleraBalance -= vleraTerheqje;
        alert(`Ti terhoqe ${vleraTerheqje} lek`);
    } else {
        alert("Ju lutem, jepni nje vlere te vlefshme per terheqjen ose keni me shume se sa keni ne balance.");
    }
    alert(`Balanca jote eshte ${vleraBalance} lek`);
});

balanca.addEventListener("click", function() {
    alert(`Balanca jote eshte ${vleraBalance} lek`);
});