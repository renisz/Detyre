
particlesJS('particles-js', {
  particles: {
    number: {
      value: 80,
      density: {
        enable: true,
        value_area: 800
      }
    },
    color: {
      value: "#3b5998"
    },
    shape: {
      type: "circle"
    },
    opacity: {
      value: 1,
      random: true,
      anim: {
        enable: true,
        speed: 1,
        opacity_min: 0
      }
    },
    size: {
      value: 3,
      random: true,
      anim: {
        enable: false
      }
    },
    line_linked: {
      enable: true,
      distance: 150,
      color: "#3b5998",
      opacity: 0.4,
      width: 1
    },
    move: {
      enable: true,
      speed: 2,
      direction: "none",
      random: true,
      straight: false
    }
  },
  interactivity: {
    detect_on: "canvas",
    events: {
      onhover: {
        enable: true,
        mode: "repulse"
      }
    }
  }
});


function getRandomUser() {
  const friendsList = document.querySelectorAll('.friends-list li');
  const randomIndex = Math.floor(Math.random() * friendsList.length);
  return friendsList[randomIndex];
}
function toggleUserStatus() {
  const user = getRandomUser();


    if (user.classList.contains('online')) {
      user.classList.remove('online');
      user.classList.add('offline');
    } else {
      user.classList.remove('offline');
      user.classList.add('online');
    }
  
}
setInterval(toggleUserStatus, 5000);






document.getElementById("postButton").addEventListener("click", function () {
  const postText = document.querySelector(".post-box textarea").value;

  if (postText.trim() !== "") {
    const newPost = document.createElement("div");
    newPost.classList.add("post");

    const time = new Date().toLocaleString();

    newPost.innerHTML = `
      <div class="post-header">
        <div class="user">You</div>
        <div class="time">${time}</div>
        <div class="post-options">
          <i class="fas fa-ellipsis-h"></i>
          <div class="options-menu">
            <ul>
              <li class="remove-post">Remove</li>
              <li class="report-post">Report</li>
            </ul>
          </div>
        </div>
      </div>
      <p>${postText}</p>
    `;

    document.getElementById("postContainer").prepend(newPost);

    document.querySelector(".post-box textarea").value = "";
  }
});

document.addEventListener("click", function (e) {
  if (e.target.closest(".post-options")) {
    const menu = e.target
      .closest(".post-options")
      .querySelector(".options-menu");
    menu.style.display = menu.style.display === "block" ? "none" : "block";
  } else {
    document.querySelectorAll(".options-menu").forEach((menu) => {
      menu.style.display = "none";
    });
  }
});


document.addEventListener("click", function (e) {
  if (e.target.classList.contains("remove-post")) {
    const post = e.target.closest(".post");
    post.remove();
  }
});

document.addEventListener("click", function (e) {
  if (e.target.classList.contains("report-post")) {
    alert("This post has been reported!");
  }
});


/*
for(let i = 1;i <= 100;i++){
  if(i % 3 == 0  && i % 5 == 0){
      console.log("fizzbuzz")
  }
   if(i % 3 == 0 ){
      console.log("fizz")
  }
   if(i % 3 == 0){
      console.log("buzz")
  }
}




  let word = prompt("Shkruaj emrin/fjalen");

  word = word.replace(/[^A-Za-z]/g, "").toLowerCase();


  let isPalindrome = true;
  for (let i = 0; i < Math.floor(word.length / 2); i++) {
      if (word[i] !== word[word.length - 1 - i]) {
          isPalindrome = false;
          break;
      }
  }

  if (isPalindrome) {
      console.log("Palindrom");
  } else {
      console.log("Nuk eshte palindrom");
      
  }


let numbers = [1, 2, 3, 4];
let doubled = numbers.map(function(num) {
return num * 2;
});

console.log(doubled);
*/
